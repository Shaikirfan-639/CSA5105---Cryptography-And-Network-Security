# CSA51 Cryptography and Network Security – Assessment Tool 3

This repository contains Python implementations for all five debugging and optimisation questions from Assessment Tool 3.

## Assessment Questions Covered

1. Debugging & Optimization of Symmetric Encryption (DES / 3DES)
2. Performance Analysis of Block Cipher Modes (ECB, CBC, CFB, OFB)
3. Debugging RSA Cryptosystem Implementation
4. Optimization and Security Analysis of Diffie-Hellman Key Exchange
5. Debugging and Enhancing Elliptic Curve Cryptography (ECC)

## Requirements

```bash
pip install pycryptodome cryptography
```

## Run

```bash
python q1_des_3des.py
python q2_block_modes.py
python q3_rsa.py
python q4_diffie_hellman.py
python q5_ecc.py
```

## Notes

- DES and 3DES are included for educational comparison only. Modern applications should use AES.
- RSA uses OAEP for encryption and demonstrates CRT-based private-key computation.
- Diffie-Hellman demonstrates authenticated key exchange using signatures to reduce MITM risk.
- ECC uses a small educational curve implementation and is not intended for production cryptography.
